/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ict.entity;

/**
 *
 * @author Shawon
 */
public class myClass {
private static String name;
private String status;

    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        myClass.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


}
